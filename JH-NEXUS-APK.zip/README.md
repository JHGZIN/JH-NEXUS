# JH NEXUS

Assistente Android experimental com estética de terminal futurista JH, agenda local, comandos por voz em português e estimativa do tempo de uso da Godot.

## Incluído
- Agenda de tarefas com data, hora, conclusão e exclusão, salva no aparelho.
- Reconhecimento de voz e resposta falada via serviços nativos do Android.
- Comandos básicos: agenda, horas da Godot, horário, saudações e ajuda.
- Núcleo visual animado, tema grafite/ciano e configuração de acesso de uso.
- Leitura aproximada do tempo em primeiro plano de apps cujo nome de pacote contém `godot`, após conceder Acesso de uso nas configurações do Android.

## Limitações
- Não é uma IA generativa online; os comandos são limitados e não entende perguntas abertas.
- A leitura da Godot é uma estimativa do Android e pode variar por aparelho. Ela mede o app em primeiro plano, não tempo real de edição dentro do projeto.
- O reconhecimento de voz pode depender de internet e do mecanismo de fala instalado.
- Não foi possível compilar/testar este projeto neste ambiente; valide o workflow e envie o log se ocorrer erro.

## GitHub Actions
Extraia o conteúdo deste ZIP na raiz do repositório. Depois coloque o workflow separado em `.github/workflows/build.yml`, faça commit e abra Actions para executar `Build JH NEXUS APK`. O artefato `JH-NEXUS-APK` conterá o APK de depuração.
