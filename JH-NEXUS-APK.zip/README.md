# JH NEXUS 2.0 — projeto Android

Projeto Kotlin nativo, pacote `com.jh.nexus`, com tema grafite/ciano e sem dependências extras além de Activity KTX.

## Melhorias desta revisão
- Agenda com descrição, categoria, prioridade, busca, contadores, edição e confirmação de exclusão.
- Persistência ampliada em SharedPreferences, compatível com registros antigos no formato de quatro campos. Os novos campos são serializados sem perder separadores no texto.
- Lembretes locais por `AlarmManager` não exato e notificação Android. A entrega depende das permissões e das políticas de bateria/notificação do aparelho; lembretes não são garantidos após reinicialização do dispositivo.
- Respostas de voz configuráveis e erros do reconhecimento mais claros.
- Comandos locais para data, horário, resumo da agenda, tarefas concluídas e estimativa de uso da Godot.
- Opção de reduzir animações e preferência persistente para fala.
- Workflow GitHub Actions para gerar o APK de depuração.

## Limitações conhecidas
- Os comandos de voz são locais e baseados em regras; não existe modelo de IA generativa ou serviço remoto.
- O tempo da Godot é uma estimativa de uso em primeiro plano fornecida pelo Android, depende de Acesso de uso e não representa tempo produtivo comprovado.
- Lembretes usam alarmes não exatos para respeitar restrições recentes do Android. O app não restaura alarmes depois de reiniciar o aparelho nesta versão.
- As tarefas permanecem no armazenamento local privado do app. A atualização preserva o formato antigo de tarefas, mas recomenda-se manter backup antes de instalar builds experimentais.

## Compilar
1. Abra a pasta extraída no Android Studio (JDK 17).
2. Aguarde a sincronização do Gradle e aceite a instalação do Android SDK 35, se solicitada.
3. Execute **Build > Build Bundle(s) / APK(s) > Build APK(s)** ou rode `gradle assembleDebug` com Gradle 8.7.
4. O APK de depuração esperado fica em `app/build/outputs/apk/debug/app-debug.apk`.

Também é possível enviar o projeto para um repositório GitHub e executar o workflow **Build JH NEXUS APK** em Actions. Este ZIP não inclui Gradle Wrapper porque ele não existia no projeto recebido.
