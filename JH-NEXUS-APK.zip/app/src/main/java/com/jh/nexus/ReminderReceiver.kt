package com.jh.nexus

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Tarefa JH NEXUS"
        val description = intent.getStringExtra("description").orEmpty().ifBlank { "Está na hora da sua tarefa." }
        val channelId = intent.getStringExtra("channel") ?: "jh_nexus_reminders"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Lembretes JH NEXUS", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(context, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(context)
        }.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(description)
            .setStyle(Notification.BigTextStyle().bigText(description))
            .setAutoCancel(true)
            .build()
        try { manager.notify(title.hashCode(), notification) } catch (_: SecurityException) { }
    }
}
