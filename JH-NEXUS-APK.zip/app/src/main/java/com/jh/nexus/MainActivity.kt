
package com.jh.nexus

import android.Manifest
import android.app.*
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.sin

data class Task(
    val title: String,
    val date: String,
    val time: String,
    val done: Boolean = false
)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private val bg = 0xFF050A12.toInt()
    private val panel = 0xFF0B1725.toInt()
    private val cyan = 0xFF00E5FF.toInt()
    private val fg = 0xFFEAF7FF.toInt()
    private val muted = 0xFF8DA6B8.toInt()

    private val prefs by lazy {
        getSharedPreferences("nexus", MODE_PRIVATE)
    }

    private val tasks = mutableListOf<Task>()

    private lateinit var taskBox: LinearLayout
    private lateinit var workLabel: TextView
    private lateinit var status: TextView

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    private val df = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val ptDate = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))

    private val mic = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { permitido ->
        if (permitido) {
            listen()
        } else {
            say("Preciso da permissão do microfone, senhor JH.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = bg
        window.navigationBarColor = bg

        tts = TextToSpeech(this, this)

        loadTasks()
        ui()
        refreshTime()
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("pt", "BR"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                result != TextToSpeech.LANG_NOT_SUPPORTED

            if (!ttsReady) {
                statusSafe("SERVIÇO DE VOZ INDISPONÍVEL")
            }
        }
    }

    private fun statusSafe(message: String) {
        if (::status.isInitialized) {
            status.text = message
        }
    }

    private fun ui() {
        val scroll = ScrollView(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(18), d(14), d(18), d(24))
            setBackgroundColor(bg)
        }

        scroll.addView(col)
        setContentView(scroll)

        col.addView(txt("JH / NEXUS", 12, cyan, true))
        col.addView(txt("ASSISTENTE DE SISTEMA", 24, fg, true))
        col.addView(txt("PERSONAL AI CORE • BUILD 01", 10, muted, true))
        col.addView(Orb(this), LinearLayout.LayoutParams(-1, d(150)))

        status = txt(
            "SISTEMA ONLINE / AGUARDANDO COMANDO",
            10,
            cyan,
            true
        ).apply {
            gravity = Gravity.CENTER
            setPadding(0, d(8), 0, d(10))
        }

        col.addView(status)

        col.addView(header("TEMPO DE DESENVOLVIMENTO"))

        val work = card()
        workLabel = txt("-- h -- min", 25, fg, true)
        work.addView(workLabel)

        work.addView(
            txt(
                "Estimativa diária do tempo em que a Godot ficou em primeiro plano. Requer acesso de uso do Android.",
                12,
                muted,
                false
            )
        )

        work.addView(btn("CONFIGURAR ACESSO DE USO") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })

        work.addView(btn("ATUALIZAR TEMPO") {
            refreshTime()
        })

        col.addView(work)

        col.addView(header("AGENDA / MISSÕES"))

        val agenda = card()

        agenda.addView(
            txt(
                "Tarefas com data, horário e estado de conclusão, salvas no aparelho.",
                12,
                muted,
                false
            )
        )

        agenda.addView(btn("+ NOVA TAREFA") {
            addTask()
        })

        taskBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        agenda.addView(taskBox)
        col.addView(agenda)

        renderTasks()

        col.addView(header("INTERFACE DE VOZ"))

        val voice = card()

        voice.addView(
            txt(
                "Converse por voz em português. A fala usa o serviço instalado no Android.",
                12,
                muted,
                false
            )
        )

        voice.addView(btn("◉  FALAR COM NEXUS") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                mic.launch(Manifest.permission.RECORD_AUDIO)
            } else {
                listen()
            }
        })

        voice.addView(btn("TESTAR RESPOSTA DE VOZ") {
            say("Sistemas online, senhor JH. Pronto para sua próxima tarefa.")
        })

        col.addView(voice)

        col.addView(header("CONFIGURAÇÕES DO NÚCLEO"))

        val settings = card()

        settings.addView(btn("TESTAR PERFIL: SENHOR JH") {
            say("Perfil de tratamento ativo, senhor JH.")
        })

        settings.addView(btn("CONFIGURAÇÕES DO APLICATIVO") {
            startActivity(
                Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")
                )
            )
        })

        settings.addView(btn("SOBRE O JH NEXUS") {
            AlertDialog.Builder(this)
                .setTitle("JH NEXUS • BUILD 01")
                .setMessage(
                    "Assistente experimental com agenda local, comandos de voz e estimativa de uso da Godot. Não envia seus dados para servidores."
                )
                .setPositiveButton("OK", null)
                .show()
        })

        col.addView(settings)

        col.addView(
            txt("JH STUDIOS // SYSTEMS FORGED BY YOU", 9, muted, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, d(22), 0, 0)
            }
        )
    }

    private fun d(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    private fun txt(
        textValue: String,
        size: Int,
        color: Int,
        mono: Boolean
    ): TextView {
        return TextView(this).apply {
            text = textValue
            textSize = size.toFloat()
            setTextColor(color)

            if (mono) {
                typeface = Typeface.MONOSPACE
            }

            setPadding(0, d(5), 0, d(5))
        }
    }

    private fun header(textValue: String): TextView {
        return txt(textValue, 11, cyan, true).apply {
            setPadding(0, d(18), 0, d(8))
        }
    }

    private fun card(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(13), d(13), d(13), d(13))
            background = shape(panel, 14, 0xFF194056.toInt())
            layoutParams = LinearLayout.LayoutParams(-1, -2)
        }
    }

    private fun shape(
        color: Int,
        radius: Int,
        stroke: Int
    ): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = d(radius).toFloat()
            setStroke(d(1), stroke)
        }
    }

    private fun btn(
        label: String,
        act: () -> Unit
    ): Button {
        return Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            setTextColor(cyan)
            typeface = Typeface.MONOSPACE
            background = shape(0xFF102638.toInt(), 9, 0xFF176079.toInt())
            setPadding(d(8), d(5), d(8), d(5))

            layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = d(7)
            }

            setOnClickListener {
                act()
            }
        }
    }

    private fun addTask() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(18), d(8), d(18), 0)
        }

        val name = EditText(this).apply {
            hint = "O que você vai fazer?"
            setTextColor(fg)
            setHintTextColor(muted)
        }

        val dateBtn = Button(this).apply {
            text = "DATA: HOJE"
        }

        val timeBtn = Button(this).apply {
            text = "HORÁRIO: 09:00"
        }

        var date = df.format(Date())
        var time = "09:00"

        dateBtn.setOnClickListener {
            val calendar = Calendar.getInstance()

            DatePickerDialog(
                this,
                { _, year, month, day ->
                    calendar.set(year, month, day)
                    date = df.format(calendar.time)
                    dateBtn.text = "DATA: ${ptDate.format(calendar.time)}"
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        timeBtn.setOnClickListener {
            TimePickerDialog(
                this,
                { _, hour, minute ->
                    time = "%02d:%02d".format(hour, minute)
                    timeBtn.text = "HORÁRIO: $time"
                },
                9,
                0,
                true
            ).show()
        }

        box.addView(name)
        box.addView(dateBtn)
        box.addView(timeBtn)

        AlertDialog.Builder(this)
            .setTitle("NOVA MISSÃO")
            .setView(box)
            .setNegativeButton("CANCELAR", null)
            .setPositiveButton("SALVAR") { _, _ ->
                val taskName = name.text.toString().trim()

                if (taskName.isNotEmpty()) {
                    tasks.add(Task(taskName, date, time))
                    saveTasks()
                    renderTasks()
                    say("Tarefa adicionada à agenda, senhor JH.")
                } else {
                    say("A tarefa está sem título, senhor JH.")
                }
            }
            .show()
    }

    private fun renderTasks() {
        if (!::taskBox.isInitialized) return

        taskBox.removeAllViews()

        if (tasks.isEmpty()) {
            taskBox.addView(
                txt("Nenhuma missão agendada.", 12, muted, false)
            )
            return
        }

        tasks.sortedWith(
            compareBy<Task> { it.date }.thenBy { it.time }
        ).forEach { task ->

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val check = CheckBox(this).apply {
                isChecked = task.done
                buttonTintList = ColorStateList.valueOf(cyan)

                setOnCheckedChangeListener { _, checked ->
                    val index = tasks.indexOf(task)

                    if (index >= 0) {
                        tasks[index] = task.copy(done = checked)
                        saveTasks()
                        renderTasks()
                    }
                }
            }

            row.addView(check)

            row.addView(
                txt(
                    "${task.title}\n${formatDate(task.date)} • ${task.time}",
                    12,
                    if (task.done) muted else fg,
                    false
                ),
                LinearLayout.LayoutParams(0, -2, 1f)
            )

            row.addView(
                txt("×", 22, 0xFFFF4568.toInt(), false).apply {
                    setOnClickListener {
                        tasks.remove(task)
                        saveTasks()
                        renderTasks()
                    }
                }
            )

            taskBox.addView(row)
        }
    }

    private fun formatDate(value: String): String {
        return try {
            ptDate.format(df.parse(value)!!)
        } catch (_: Exception) {
            value
        }
    }

    private fun saveTasks() {
        val serialized = tasks.joinToString("\n") {
            "${it.title}|${it.date}|${it.time}|${it.done}"
        }

        prefs.edit().putString("tasks", serialized).apply()
    }

    private fun loadTasks() {
        val saved = prefs.getString("tasks", "").orEmpty()

        saved.lines()
            .filter { it.contains('|') }
            .forEach { line ->
                val parts = line.split('|', limit = 4)

                if (parts.size == 4) {
                    tasks.add(
                        Task(
                            parts[0],
                            parts[1],
                            parts[2],
                            parts[3].toBoolean()
                        )
                    )
                }
            }
    }

    private fun refreshTime() {
        try {
            val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager

            @Suppress("DEPRECATION")
            val mode = ops.checkOpNoThrow(
                "android:get_usage_stats",
                android.os.Process.myUid(),
                packageName
            )

            if (mode != AppOpsManager.MODE_ALLOWED) {
                workLabel.text = "ACESSO NECESSÁRIO"
                status.text = "AGUARDANDO PERMISSÃO DE USO"
                return
            }

            val calendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }

            val stats = (
                getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
            ).queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                calendar.timeInMillis,
                System.currentTimeMillis()
            ).filter {
                it.packageName.contains("godot", ignoreCase = true)
            }

            val minutes = stats.sumOf {
                it.totalTimeInForeground
            } / 60000

            workLabel.text = if (stats.isEmpty()) {
                "SEM DADOS DA GODOT"
            } else {
                "%02d h %02d min".format(minutes / 60, minutes % 60)
            }

            status.text = "SISTEMA ONLINE / DADOS ATUALIZADOS"

        } catch (_: Exception) {
            workLabel.text = "NÃO DISPONÍVEL"
            status.text = "NÃO FOI POSSÍVEL CONSULTAR O USO"
        }
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("O reconhecimento de voz não está disponível, senhor JH.")
            return
        }

        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)

            recognizer?.setRecognitionListener(object : RecognitionListener {

                override fun onReadyForSpeech(params: Bundle?) {
                    status.text = "OUVINDO / FALE AGORA"
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    status.text = "PROCESSANDO COMANDO"
                }

                override fun onError(error: Int) {
                    say("Não consegui entender, senhor JH. Pode repetir?")
                }

                override fun onResults(results: Bundle?) {
                    val recognized = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()

                    command(recognized)
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com JH NEXUS")
            }

            recognizer?.startListening(intent)

        } catch (_: Exception) {
            say("Não consegui iniciar o sistema de voz, senhor JH.")
        }
    }

    private fun command(raw: String) {
        val input = raw.lowercase(Locale("pt", "BR"))

        status.text = "COMANDO: ${raw.uppercase(Locale("pt", "BR"))}"

        when {
            input.isBlank() -> {
                say("Não consegui entender, senhor JH. Pode repetir?")
            }

            listOf("agenda", "tarefas", "missões", "missao")
                .any { input.contains(it) } -> {
                say(
                    "Senhor JH, você tem ${tasks.count { !it.done }} tarefas pendentes na agenda."
                )
            }

            listOf("godot", "horas", "trabalhei", "tempo de trabalho")
                .any { input.contains(it) } -> {
                refreshTime()
                say(
                    "Senhor JH, o tempo estimado de uso da Godot hoje é ${workLabel.text}."
                )
            }

            listOf("que horas", "horário", "hora agora")
                .any { input.contains(it) } -> {
                val currentTime = SimpleDateFormat(
                    "HH:mm",
                    Locale("pt", "BR")
                ).format(Date())

                say("Agora são $currentTime, senhor JH.")
            }

            listOf("olá", "ola", "oi", "bom dia", "boa tarde", "boa noite")
                .any { input.contains(it) } -> {
                say(
                    "Sistemas online, senhor JH. Como posso ajudar no desenvolvimento hoje?"
                )
            }

            input.contains("ajuda") || input.contains("comandos") -> {
                say(
                    "Você pode perguntar sobre agenda, tempo de Godot, horário atual ou pedir ajuda."
                )
            }

            else -> {
                say(
                    "Não consegui entender, senhor JH. Por enquanto consigo consultar agenda, tempo da Godot e horário."
                )
            }
        }
    }

    private fun say(message: String) {
        statusSafe(message.uppercase(Locale("pt", "BR")))

        if (ttsReady) {
            tts?.speak(
                message,
                TextToSpeech.QUEUE_FLUSH,
                null,
                "nexus"
            )
        }

        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onResume() {
        super.onResume()

        if (::workLabel.isInitialized) {
            refreshTime()
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null

        tts?.stop()
        tts?.shutdown()
        tts = null

        super.onDestroy()
    }

    private class Orb(context: Context) : View(context) {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val start = System.currentTimeMillis()

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            val x = width / 2f
            val y = height / 2f
            val elapsed = (System.currentTimeMillis() - start) / 1000f
            val pulse = 1f + 0.05f * sin(elapsed * 2)

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(1).toFloat()
            paint.color = 0xFF12546B.toInt()

            for (i in 0..3) {
                canvas.drawCircle(
                    x,
                    y,
                    dp(27 + i * 15) * pulse,
                    paint
                )
            }

            paint.color = 0xFF00E5FF.toInt()
            paint.strokeWidth = dp(2).toFloat()

            canvas.drawArc(
                RectF(
                    x - dp(55),
                    y - dp(55),
                    x + dp(55),
                    y + dp(55)
                ),
                elapsed * 28,
                95f,
                false,
                paint
            )

            paint.style = Paint.Style.FILL
            paint.color = 0xFF0C2D43.toInt()
            canvas.drawCircle(x, y, dp(31) * pulse, paint)

            paint.color = 0xFF00E5FF.toInt()
            canvas.drawCircle(x, y, dp(21) * pulse, paint)

            paint.color = 0xFF07111D.toInt()
            canvas.drawCircle(x, y, dp(14) * pulse, paint)

            paint.color = 0xFFBDFBFF.toInt()
            canvas.drawCircle(x, y, dp(5) * pulse, paint)

            paint.color = 0xFF00E5FF.toInt()
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = dp(9).toFloat()
            paint.typeface = Typeface.MONOSPACE

            canvas.drawText(
                "NEXUS CORE",
                x,
                y + dp(75),
                paint
            )

            postInvalidateDelayed(50)
        }

        private fun dp(value: Int): Int {
            return (value * resources.displayMetrics.density).toInt()
        }
    }
}
