
package com.jh.nexus

import android.Manifest
import android.app.*
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.sin

data class Task(
    val title: String,
    val date: String,
    val time: String,
    val done: Boolean = false,
    val description: String = "",
    val category: String = "Pessoal",
    val priority: String = "Normal",
    val reminder: Boolean = false
)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private val bg = 0xFF050A12.toInt()
    private val panel = 0xFF0B1725.toInt()
    private val cyan = 0xFF00E5FF.toInt()
    private val fg = 0xFFEAF7FF.toInt()
    private val muted = 0xFF8DA6B8.toInt()

    private val prefs by lazy {
        getSharedPreferences("nexus", MODE_PRIVATE)
    }

    private val tasks = mutableListOf<Task>()

    private lateinit var taskBox: LinearLayout
    private lateinit var workLabel: TextView
    private lateinit var status: TextView

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    private val df = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val ptDate = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))

    private val mic = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { permitido ->
        if (permitido) {
            listen()
        } else {
            say("Preciso da permissão do microfone, senhor JH.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = bg
        window.navigationBarColor = bg

        tts = TextToSpeech(this, this)

        loadTasks()
        ui()
        refreshTime()
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("pt", "BR"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                result != TextToSpeech.LANG_NOT_SUPPORTED

            if (!ttsReady) {
                statusSafe("SERVIÇO DE VOZ INDISPONÍVEL")
            }
        }
    }

    private fun statusSafe(message: String) {
        if (::status.isInitialized) {
            status.text = message
        }
    }

    private fun ui() {
        val scroll = ScrollView(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(18), d(14), d(18), d(24))
            setBackgroundColor(bg)
        }

        scroll.addView(col)
        setContentView(scroll)

        col.addView(txt("JH / NEXUS", 12, cyan, true))
        col.addView(txt("ASSISTENTE DE SISTEMA", 24, fg, true))
        col.addView(txt("PERSONAL AI CORE • BUILD 01", 10, muted, true))
        col.addView(Orb(this), LinearLayout.LayoutParams(-1, d(150)))

        status = txt(
            "SISTEMA ONLINE / AGUARDANDO COMANDO",
            10,
            cyan,
            true
        ).apply {
            gravity = Gravity.CENTER
            setPadding(0, d(8), 0, d(10))
        }

        col.addView(status)

        col.addView(header("TEMPO DE DESENVOLVIMENTO"))

        val work = card()
        workLabel = txt("-- h -- min", 25, fg, true)
        work.addView(workLabel)

        work.addView(
            txt(
                "Estimativa diária do tempo em que a Godot ficou em primeiro plano. Requer acesso de uso do Android.",
                12,
                muted,
                false
            )
        )

        work.addView(btn("CONFIGURAR ACESSO DE USO") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })

        work.addView(btn("ATUALIZAR TEMPO") {
            refreshTime()
        })

        col.addView(work)

        col.addView(header("AGENDA / MISSÕES"))

        val agenda = card()

        agenda.addView(
            txt(
                "Tarefas com data, horário e estado de conclusão, salvas no aparelho.",
                12,
                muted,
                false
            )
        )

        agenda.addView(btn("+ NOVA TAREFA") {
            addTask()
        })

        taskBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val search = EditText(this).apply {
            hint = "Pesquisar tarefas..."
            setTextColor(fg)
            setHintTextColor(muted)
            singleLine = true
            background = shape(0xFF08121E.toInt(), 10, 0xFF194056.toInt())
            setPadding(d(12), d(10), d(12), d(10))
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderTasks(s?.toString().orEmpty()) }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        agenda.addView(search)
        agenda.addView(txt("Toque em uma tarefa para editar. Use a caixa para concluir.", 11, muted, false))
        agenda.addView(taskBox)
        col.addView(agenda)

        renderTasks()

        col.addView(header("INTERFACE DE VOZ"))

        val voice = card()

        voice.addView(
            txt(
                "Converse por voz em português. A fala usa o serviço instalado no Android.",
                12,
                muted,
                false
            )
        )

        voice.addView(btn("◉  FALAR COM NEXUS") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                mic.launch(Manifest.permission.RECORD_AUDIO)
            } else {
                listen()
            }
        })

        voice.addView(btn("TESTAR RESPOSTA DE VOZ") {
            say("Sistemas online, senhor JH. Pronto para sua próxima tarefa.")
        })

        col.addView(voice)

        col.addView(header("CONFIGURAÇÕES DO NÚCLEO"))

        val settings = card()

        val voiceEnabled = CheckBox(this).apply {
            text = "Resposta falada ativada"
            setTextColor(fg); buttonTintList = ColorStateList.valueOf(cyan)
            isChecked = prefs.getBoolean("voice_enabled", true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("voice_enabled", checked).apply() }
        }
        settings.addView(voiceEnabled)
        val reducedMotion = CheckBox(this).apply {
            text = "Reduzir animações"
            setTextColor(fg); buttonTintList = ColorStateList.valueOf(cyan)
            isChecked = prefs.getBoolean("reduced_motion", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("reduced_motion", checked).apply()
                Toast.makeText(this@MainActivity, "A preferência será aplicada ao reiniciar a tela.", Toast.LENGTH_SHORT).show()
            }
        }
        settings.addView(reducedMotion)
        settings.addView(btn("NOTIFICAÇÕES E PERMISSÕES") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        settings.addView(btn("TESTAR PERFIL: SENHOR JH") {
            say("Perfil de tratamento ativo, senhor JH.")
        })

        settings.addView(btn("CONFIGURAÇÕES DO APLICATIVO") {
            startActivity(
                Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:$packageName")
                )
            )
        })

        settings.addView(btn("SOBRE O JH NEXUS") {
            AlertDialog.Builder(this)
                .setTitle("JH NEXUS • BUILD 01")
                .setMessage(
                    "Assistente experimental com agenda local, comandos de voz e estimativa de uso da Godot. Não envia seus dados para servidores."
                )
                .setPositiveButton("OK", null)
                .show()
        })

        col.addView(settings)

        col.addView(
            txt("JH STUDIOS // SYSTEMS FORGED BY YOU", 9, muted, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, d(22), 0, 0)
            }
        )
    }

    private fun d(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    private fun txt(
        textValue: String,
        size: Int,
        color: Int,
        mono: Boolean
    ): TextView {
        return TextView(this).apply {
            text = textValue
            textSize = size.toFloat()
            setTextColor(color)

            if (mono) {
                typeface = Typeface.MONOSPACE
            }

            setPadding(0, d(5), 0, d(5))
        }
    }

    private fun header(textValue: String): TextView {
        return txt(textValue, 11, cyan, true).apply {
            setPadding(0, d(18), 0, d(8))
        }
    }

    private fun card(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(13), d(13), d(13), d(13))
            background = shape(panel, 14, 0xFF194056.toInt())
            layoutParams = LinearLayout.LayoutParams(-1, -2)
        }
    }

    private fun shape(
        color: Int,
        radius: Int,
        stroke: Int
    ): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = d(radius).toFloat()
            setStroke(d(1), stroke)
        }
    }

    private fun btn(
        label: String,
        act: () -> Unit
    ): Button {
        return Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            setTextColor(cyan)
            typeface = Typeface.MONOSPACE
            background = shape(0xFF102638.toInt(), 9, 0xFF176079.toInt())
            setPadding(d(8), d(5), d(8), d(5))

            layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = d(7)
            }

            setOnClickListener {
                act()
            }
        }
    }

    private fun addTask(existing: Task? = null) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(6), d(6), d(6), 0)
        }
        fun field(hintText: String, initial: String = "", multiline: Boolean = false) = EditText(this).apply {
            hint = hintText
            setText(initial)
            setTextColor(fg)
            setHintTextColor(muted)
            textSize = 14f
            setPadding(d(10), d(8), d(10), d(8))
            background = shape(0xFF08121E.toInt(), 8, 0xFF194056.toInt())
            if (multiline) { minLines = 2; gravity = Gravity.TOP }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(6) }
        }
        val name = field("Nome da tarefa *", existing?.title.orEmpty())
        val description = field("Descrição (opcional)", existing?.description.orEmpty(), true)
        val dateBtn = btn("DATA: ${existing?.let { formatDate(it.date) } ?: "HOJE"}") { }
        val timeBtn = btn("HORÁRIO: ${existing?.time ?: "09:00"}") { }
        var date = existing?.date ?: df.format(Date())
        var time = existing?.time ?: "09:00"
        dateBtn.setOnClickListener {
            val cal = Calendar.getInstance()
            try { cal.time = df.parse(date) ?: Date() } catch (_: Exception) {}
            DatePickerDialog(this, { _, y, m, day ->
                cal.set(y, m, day); date = df.format(cal.time); dateBtn.text = "DATA: ${ptDate.format(cal.time)}"
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        timeBtn.setOnClickListener {
            val parts = time.split(":")
            TimePickerDialog(this, { _, h, m -> time = "%02d:%02d".format(h, m); timeBtn.text = "HORÁRIO: $time" },
                parts.getOrNull(0)?.toIntOrNull() ?: 9, parts.getOrNull(1)?.toIntOrNull() ?: 0, true).show()
        }
        val category = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Desenvolvimento", "Estudos", "Trabalho", "Pessoal"))
            setSelection((0 until count).firstOrNull { getItemAtPosition(it).toString() == existing?.category } ?: 3)
        }
        val priority = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Baixa", "Normal", "Alta", "Urgente"))
            setSelection((0 until count).firstOrNull { getItemAtPosition(it).toString() == existing?.priority } ?: 1)
        }
        val reminder = CheckBox(this).apply {
            text = "Lembrete local (notificação)"
            setTextColor(fg); buttonTintList = ColorStateList.valueOf(cyan)
            isChecked = existing?.reminder ?: false
        }
        box.addView(name); box.addView(description); box.addView(dateBtn); box.addView(timeBtn)
        box.addView(txt("CATEGORIA", 10, cyan, true)); box.addView(category)
        box.addView(txt("PRIORIDADE", 10, cyan, true)); box.addView(priority); box.addView(reminder)
        val dialog = AlertDialog.Builder(this).setTitle(if (existing == null) "NOVA TAREFA" else "EDITAR TAREFA")
            .setView(box).setNegativeButton("CANCELAR", null)
            .setPositiveButton("SALVAR", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val title = name.text.toString().trim()
                if (title.isBlank()) { name.error = "Informe o nome da tarefa"; return@setOnClickListener }
                val updated = Task(title, date, time, existing?.done ?: false,
                    description.text.toString().trim(), category.selectedItem.toString(),
                    priority.selectedItem.toString(), reminder.isChecked)
                if (existing == null) tasks.add(updated) else {
                    val idx = tasks.indexOf(existing)
                    if (idx >= 0) tasks[idx] = updated
                }
                saveTasks(); renderTasks(); dialog.dismiss()
                if (reminder.isChecked) scheduleReminder(updated)
            }
        }
        dialog.show()
    }

    private fun scheduleReminder(task: Task) {
        // Lembrete local por notificação. O sistema pode limitar alarmes exatos; usamos alarmes não exatos.
        try {
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                statusSafe("PERMISSÃO DE NOTIFICAÇÃO NECESSÁRIA")
                Toast.makeText(this, "Ative as notificações nas configurações do aplicativo para receber lembretes.", Toast.LENGTH_LONG).show()
                return
            }
            val cal = Calendar.getInstance()
            val dateParts = task.date.split("-").mapNotNull { it.toIntOrNull() }
            val timeParts = task.time.split(":").mapNotNull { it.toIntOrNull() }
            if (dateParts.size != 3 || timeParts.size != 2) return
            cal.set(dateParts[0], dateParts[1] - 1, dateParts[2], timeParts[0], timeParts[1], 0)
            if (cal.timeInMillis <= System.currentTimeMillis()) return
            val channelId = "jh_nexus_reminders"
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                val manager = getSystemService(NotificationManager::class.java)
                manager.createNotificationChannel(NotificationChannel(channelId, "Lembretes JH NEXUS", NotificationManager.IMPORTANCE_DEFAULT))
            }
            val id = (task.title + task.date + task.time).hashCode() and 0x7fffffff
            val intent = Intent(this, ReminderReceiver::class.java).apply {
                putExtra("title", task.title); putExtra("description", task.description); putExtra("channel", channelId)
            }
            val pending = PendingIntent.getBroadcast(this, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            (getSystemService(ALARM_SERVICE) as AlarmManager).set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
        } catch (_: Exception) {
            statusSafe("NÃO FOI POSSÍVEL PROGRAMAR O LEMBRETE")
        }
    }

    private fun renderTasks(query: String = "") {
        if (!::taskBox.isInitialized) return
        taskBox.removeAllViews()
        val filtered = tasks.filter { it.title.contains(query, true) || it.description.contains(query, true) }
            .sortedWith(compareBy<Task> { it.done }.thenBy { it.date }.thenBy { it.time })
        val pending = tasks.count { !it.done }; val completed = tasks.size - pending
        taskBox.addView(txt("$pending PENDENTES  •  $completed CONCLUÍDAS", 10, cyan, true))
        if (filtered.isEmpty()) {
            taskBox.addView(txt(if (tasks.isEmpty()) "Nenhuma tarefa agendada. Crie sua primeira missão." else "Nenhuma tarefa corresponde à pesquisa.", 12, muted, false))
            return
        }
        filtered.forEach { task ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(d(10), d(8), d(10), d(8))
                background = shape(0xFF08121E.toInt(), 10, if (task.priority == "Urgente") 0xFFFF4568.toInt() else 0xFF194056.toInt())
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(7) }
                setOnClickListener { addTask(task) }
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val check = CheckBox(this).apply {
                isChecked = task.done; buttonTintList = ColorStateList.valueOf(cyan)
                setOnCheckedChangeListener { _, checked ->
                    val idx = tasks.indexOf(task)
                    if (idx >= 0) { tasks[idx] = task.copy(done = checked); saveTasks(); renderTasks(query) }
                }
            }
            row.addView(check)
            row.addView(txt(task.title, 13, if (task.done) muted else fg, true), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(txt("×", 22, 0xFFFF4568.toInt(), false).apply {
                setPadding(d(10), 0, d(6), 0)
                setOnClickListener { AlertDialog.Builder(this@MainActivity).setTitle("Excluir tarefa?")
                    .setMessage("A tarefa ‘${task.title}’ será removida deste aparelho.")
                    .setNegativeButton("CANCELAR", null).setPositiveButton("EXCLUIR") { _, _ ->
                        tasks.remove(task); saveTasks(); renderTasks(query)
                    }.show() }
            })
            card.addView(row)
            card.addView(txt("${formatDate(task.date)} • ${task.time}  |  ${task.category} • ${task.priority}", 10,
                if (task.priority == "Urgente") 0xFFFF657D.toInt() else muted, true))
            if (task.description.isNotBlank()) card.addView(txt(task.description, 11, muted, false))
            taskBox.addView(card)
        }
    }

    private fun formatDate(value: String): String {
        return try {
            ptDate.format(df.parse(value)!!)
        } catch (_: Exception) {
            value
        }
    }

    private fun saveTasks() {
        val serialized = tasks.joinToString("\n") {
            listOf(it.title, it.date, it.time, it.done.toString(), it.description, it.category, it.priority, it.reminder.toString())
                .joinToString("|") { value -> android.util.Base64.encodeToString(value.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP) }
        }
        prefs.edit().putString("tasks", serialized).apply()
    }

    private fun loadTasks() {
        val saved = prefs.getString("tasks", "").orEmpty()

        saved.lines()
            .filter { it.contains('|') }
            .forEach { line ->
                val parts = line.split('|')

                try {
                    if (parts.size == 4) {
                        // Migração compatível com o formato original, sem descartar tarefas existentes.
                        tasks.add(Task(parts[0], parts[1], parts[2], parts[3].toBoolean()))
                    } else {
                        val values = line.split('|').map { String(android.util.Base64.decode(it, android.util.Base64.DEFAULT), Charsets.UTF_8) }
                        if (values.size >= 8) tasks.add(Task(values[0], values[1], values[2], values[3].toBoolean(), values[4], values[5], values[6], values[7].toBoolean()))
                    }
                } catch (_: Exception) { /* Ignora apenas registro corrompido; os demais permanecem disponíveis. */ }
            }
    }

    private fun refreshTime() {
        try {
            val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager

            @Suppress("DEPRECATION")
            val mode = ops.checkOpNoThrow(
                "android:get_usage_stats",
                android.os.Process.myUid(),
                packageName
            )

            if (mode != AppOpsManager.MODE_ALLOWED) {
                workLabel.text = "ACESSO NECESSÁRIO"
                status.text = "AGUARDANDO PERMISSÃO DE USO"
                return
            }

            val calendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }

            val stats = (
                getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
            ).queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                calendar.timeInMillis,
                System.currentTimeMillis()
            ).filter {
                it.packageName.contains("godot", ignoreCase = true)
            }

            val minutes = stats.sumOf {
                it.totalTimeInForeground
            } / 60000

            workLabel.text = if (stats.isEmpty()) {
                "SEM DADOS DA GODOT"
            } else {
                "%02d h %02d min".format(minutes / 60, minutes % 60)
            }

            status.text = "SISTEMA ONLINE / DADOS ATUALIZADOS"

        } catch (_: Exception) {
            workLabel.text = "NÃO DISPONÍVEL"
            status.text = "NÃO FOI POSSÍVEL CONSULTAR O USO"
        }
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("O reconhecimento de voz não está disponível, senhor JH.")
            return
        }

        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)

            recognizer?.setRecognitionListener(object : RecognitionListener {

                override fun onReadyForSpeech(params: Bundle?) {
                    status.text = "OUVINDO / FALE AGORA"
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    status.text = "PROCESSANDO COMANDO"
                }

                override fun onError(error: Int) {
                    val reason = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "Houve um problema com o microfone."
                        SpeechRecognizer.ERROR_CLIENT -> "O serviço de voz foi interrompido."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "A permissão do microfone não está disponível."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "O serviço de reconhecimento pode precisar de conexão."
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Não detectei uma fala clara."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "O reconhecimento de voz já está ocupado."
                        else -> "O reconhecimento de voz está temporariamente indisponível."
                    }
                    statusSafe("VOZ INDISPONÍVEL")
                    Toast.makeText(this@MainActivity, reason, Toast.LENGTH_LONG).show()
                }

                override fun onResults(results: Bundle?) {
                    val recognized = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()

                    command(recognized)
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com JH NEXUS")
            }

            recognizer?.startListening(intent)

        } catch (_: Exception) {
            say("Não consegui iniciar o sistema de voz, senhor JH.")
        }
    }

    private fun command(raw: String) {
        val input = raw.lowercase(Locale("pt", "BR")).trim()

        status.text = "COMANDO: ${raw.uppercase(Locale("pt", "BR"))}"

        when {
            input.isBlank() -> {
                say("Não consegui entender, senhor JH. Pode repetir?")
            }

            listOf("concluídas", "concluidas", "finalizadas").any { input.contains(it) } -> {
                say("Você concluiu ${tasks.count { it.done }} tarefas.")
            }

            listOf("agenda", "tarefas", "missões", "missao", "compromissos").any { input.contains(it) } -> {
                val pending = tasks.filter { !it.done }.sortedWith(compareBy<Task> { it.date }.thenBy { it.time })
                val today = df.format(Date())
                val todayCount = pending.count { it.date == today }
                val next = pending.firstOrNull()
                val detail = next?.let { " Próxima: ${it.title}, em ${formatDate(it.date)} às ${it.time}." } ?: " Não há tarefas pendentes."
                say("Você tem ${pending.size} tarefas pendentes, sendo $todayCount para hoje.$detail")
            }

            listOf("godot", "horas", "trabalhei", "tempo de trabalho")
                .any { input.contains(it) } -> {
                refreshTime()
                say(
                    "Senhor JH, o tempo estimado de uso da Godot hoje é ${workLabel.text}."
                )
            }

            listOf("que horas", "horário", "hora agora", "que dia", "qual a data", "data de hoje")
                .any { input.contains(it) } -> {
                val currentTime = SimpleDateFormat(
                    "HH:mm",
                    Locale("pt", "BR")
                ).format(Date())

                if (input.contains("dia") || input.contains("data")) {
                    say("Hoje é ${SimpleDateFormat("EEEE, dd 'de' MMMM 'de' yyyy", Locale("pt", "BR")).format(Date())}.")
                } else say("Agora são $currentTime, senhor JH.")
            }

            listOf("olá", "ola", "oi", "bom dia", "boa tarde", "boa noite")
                .any { input.contains(it) } -> {
                say(
                    "Sistemas online, senhor JH. Como posso ajudar no desenvolvimento hoje?"
                )
            }

            input.contains("ajuda") || input.contains("comandos") -> {
                say(
                    "Você pode perguntar sobre agenda, tempo de Godot, horário atual ou pedir ajuda."
                )
            }

            else -> {
                say(
                    "Não consegui entender, senhor JH. Por enquanto consigo consultar agenda, tempo da Godot e horário."
                )
            }
        }
    }

    private fun say(message: String) {
        statusSafe(message.uppercase(Locale("pt", "BR")))

        if (ttsReady && prefs.getBoolean("voice_enabled", true)) {
            tts?.speak(
                message,
                TextToSpeech.QUEUE_FLUSH,
                null,
                "nexus"
            )
        }

        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onResume() {
        super.onResume()

        if (::workLabel.isInitialized) {
            refreshTime()
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null

        tts?.stop()
        tts?.shutdown()
        tts = null

        super.onDestroy()
    }

    private inner class Orb(context: Context) : View(context) {
        private fun prefsReducedMotion() = prefs.getBoolean("reduced_motion", false)

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val start = System.currentTimeMillis()

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            val x = width / 2f
            val y = height / 2f
            val elapsed = (System.currentTimeMillis() - start) / 1000f
            val pulse = 1f + 0.05f * sin(elapsed * 2)

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(1).toFloat()
            paint.color = 0xFF12546B.toInt()

            for (i in 0..3) {
                canvas.drawCircle(
                    x,
                    y,
                    dp(27 + i * 15) * pulse,
                    paint
                )
            }

            paint.color = 0xFF00E5FF.toInt()
            paint.strokeWidth = dp(2).toFloat()

            canvas.drawArc(
                RectF(
                    x - dp(55),
                    y - dp(55),
                    x + dp(55),
                    y + dp(55)
                ),
                elapsed * 28,
                95f,
                false,
                paint
            )

            paint.style = Paint.Style.FILL
            paint.color = 0xFF0C2D43.toInt()
            canvas.drawCircle(x, y, dp(31) * pulse, paint)

            paint.color = 0xFF00E5FF.toInt()
            canvas.drawCircle(x, y, dp(21) * pulse, paint)

            paint.color = 0xFF07111D.toInt()
            canvas.drawCircle(x, y, dp(14) * pulse, paint)

            paint.color = 0xFFBDFBFF.toInt()
            canvas.drawCircle(x, y, dp(5) * pulse, paint)

            paint.color = 0xFF00E5FF.toInt()
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = dp(9).toFloat()
            paint.typeface = Typeface.MONOSPACE

            canvas.drawText(
                "NEXUS CORE",
                x,
                y + dp(75),
                paint
            )

            if (isShown && !prefsReducedMotion()) postInvalidateDelayed(70)
        }

        private fun dp(value: Int): Int {
            return (value * resources.displayMetrics.density).toInt()
        }
    }
}
